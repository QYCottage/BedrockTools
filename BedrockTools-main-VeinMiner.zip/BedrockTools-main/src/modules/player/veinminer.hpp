#pragma once

#include "../Module.hpp"
#include <bedrocktools/sdk/Types.hpp>
#include <cstdint>
#include <deque>
#include <string>

class VeinMinerModule : public Module {
public:
    enum class Mode : int {
        Ores = 0,
        Logs = 1,
        SameBlock = 2,
    };

    VeinMinerModule();
    ~VeinMinerModule() override;

    void onInit() override;
    void onEnable() override;
    void onDisable() override;
    void loadConfig(const nlohmann::json& j) override;
    void saveConfig(nlohmann::json& j) override;

    void onLocalPlayerTick(void* player);
    bool onDestroyBlock(void* gameMode, const bedrocktools::sdk::BlockPos& pos, std::uint8_t face);

private:
    struct QueuedBlock {
        bedrocktools::sdk::BlockPos pos{};
        std::uint8_t face = 0;
    };

    void applyHook();
    void clearQueue();
    void buildVein(void* region, const bedrocktools::sdk::BlockPos& origin, std::string_view blockName, std::uint8_t face);
    bool acceptsBlock(std::string_view blockName) const;

    bool m_hooked = false;
    void* m_patchTarget = nullptr;
    std::uint64_t m_tickSubscription = 0;

    void* m_activeGameMode = nullptr;
    void* m_activePlayer = nullptr;
    std::string m_targetBlockName;
    std::deque<QueuedBlock> m_queue;

    Mode m_mode = Mode::Ores;
    int m_maxBlocks = 32;
    int m_blocksPerTick = 1;
    bool m_diagonalConnections = true;
};
