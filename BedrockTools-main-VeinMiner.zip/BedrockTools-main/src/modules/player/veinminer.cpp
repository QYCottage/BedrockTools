#include "veinminer.hpp"

#include "core/memory/Hooks.hpp"
#include <bedrocktools/events/EventBus.hpp>
#include <bedrocktools/events/LocalPlayerTickEvent.hpp>
#include <bedrocktools/memory/Signatures.hpp>
#include <bedrocktools/sdk/Offsets.hpp>
#include <bedrocktools/sdk/render/Block.hpp>
#include <bedrocktools/sdk/world/Actor.hpp>
#include <bedrocktools/sdk/world/Dimension.hpp>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <string_view>
#include <unordered_set>
#include <vector>

namespace {
using BlockPos = bedrocktools::sdk::BlockPos;
using DestroyBlockFn = bool (*)(void*, const BlockPos&, std::uint8_t);
using GetBlockFn = void* (*)(void*, const BlockPos&);

DestroyBlockFn g_destroyBlockOriginal = nullptr;
GetBlockFn g_getBlock = nullptr;
VeinMinerModule* g_veinMiner = nullptr;

struct PosHash {
    std::size_t operator()(const BlockPos& p) const noexcept {
        std::size_t h = static_cast<std::uint32_t>(p.x) * 0x9E3779B1u;
        h ^= static_cast<std::uint32_t>(p.y) * 0x85EBCA77u + (h << 6) + (h >> 2);
        h ^= static_cast<std::uint32_t>(p.z) * 0xC2B2AE3Du + (h << 6) + (h >> 2);
        return h;
    }
};

struct PosEqual {
    bool operator()(const BlockPos& a, const BlockPos& b) const noexcept {
        return a.x == b.x && a.y == b.y && a.z == b.z;
    }
};

std::string_view blockName(void* region, const BlockPos& pos) {
    if (!region || !g_getBlock) return {};
    auto* rawBlock = g_getBlock(region, pos);
    if (!rawBlock) return {};
    auto* block = reinterpret_cast<bedrocktools::sdk::Block*>(rawBlock);
    const std::string* name = block->fullName();
    if (!name || name->empty()) return {};
    return *name;
}

bool isAir(std::string_view name) {
    return name == "minecraft:air" || name == "minecraft:cave_air" || name == "minecraft:void_air";
}

bool endsWith(std::string_view value, std::string_view suffix) {
    return value.size() >= suffix.size() && value.substr(value.size() - suffix.size()) == suffix;
}

bool isOreLike(std::string_view name) {
    // Also catches addon ores such as "myaddon:ruby_ore".
    if (name.find("_ore") != std::string_view::npos) return true;
    return name == "minecraft:ancient_debris";
}

bool isLogLike(std::string_view name) {
    // Vanilla logs/stems plus addon blocks following the usual naming convention.
    return endsWith(name, "_log") || endsWith(name, "_stem") ||
           endsWith(name, "_wood") || endsWith(name, "_hyphae");
}

void* playerFromGameMode(void* gameMode) {
    if (!gameMode) return nullptr;
    return *reinterpret_cast<void**>(reinterpret_cast<std::uintptr_t>(gameMode) + bedrocktools::sdk::offsets::GameMode::mPlayer);
}

void* regionFromPlayer(void* rawPlayer) {
    auto* player = reinterpret_cast<bedrocktools::sdk::Player*>(rawPlayer);
    if (!player) return nullptr;
    auto* dimension = player->dimension();
    return dimension ? static_cast<void*>(dimension->blockSource()) : nullptr;
}

bool destroyBlockHook(void* gameMode, const BlockPos& pos, std::uint8_t face) {
    if (!g_destroyBlockOriginal) return false;
    if (!g_veinMiner || !g_veinMiner->enabled) {
        return g_destroyBlockOriginal(gameMode, pos, face);
    }
    return g_veinMiner->onDestroyBlock(gameMode, pos, face);
}
} // namespace

VeinMinerModule::VeinMinerModule()
    : Module("Vein Miner", "Breaks connected blocks of the same vein after the first block is mined.") {
    g_veinMiner = this;
}

VeinMinerModule::~VeinMinerModule() {
    if (m_tickSubscription != 0) {
        bedrocktools::events::bus().unsubscribe(m_tickSubscription);
        m_tickSubscription = 0;
    }
    if (g_veinMiner == this) g_veinMiner = nullptr;
}

void VeinMinerModule::onInit() {
    if (!m_patchTarget) {
        const auto address = bedrocktools::memory::resolve(bedrocktools::memory::SignatureId::SurvivalModeDestroyBlock);
        if (address) m_patchTarget = reinterpret_cast<void*>(address);
    }

    if (!g_getBlock) {
        const auto address = bedrocktools::memory::resolve(bedrocktools::memory::SignatureId::BlockSourceGetBlock);
        if (address) g_getBlock = reinterpret_cast<GetBlockFn>(address);
    }

    if (m_tickSubscription == 0) {
        m_tickSubscription = bedrocktools::events::bus().subscribe<bedrocktools::events::LocalPlayerTickEvent>([](auto& event) {
            if (g_veinMiner) g_veinMiner->onLocalPlayerTick(event.player);
        });
    }
}

void VeinMinerModule::applyHook() {
    if (m_hooked || !m_patchTarget) return;
    auto handle = bedrocktools::hooks::install(
        m_patchTarget,
        reinterpret_cast<void*>(destroyBlockHook),
        reinterpret_cast<void**>(&g_destroyBlockOriginal)
    );
    m_hooked = handle != nullptr && g_destroyBlockOriginal != nullptr;
}

void VeinMinerModule::onEnable() {
    applyHook();
}

void VeinMinerModule::onDisable() {
    clearQueue();
}

void VeinMinerModule::clearQueue() {
    m_queue.clear();
    m_targetBlockName.clear();
    m_activeGameMode = nullptr;
    m_activePlayer = nullptr;
}

bool VeinMinerModule::acceptsBlock(std::string_view name) const {
    if (name.empty() || isAir(name)) return false;
    switch (m_mode) {
        case Mode::Ores: return isOreLike(name);
        case Mode::Logs: return isLogLike(name);
        case Mode::SameBlock: return true;
    }
    return false;
}

bool VeinMinerModule::onDestroyBlock(void* gameMode, const BlockPos& pos, std::uint8_t face) {
    if (!g_destroyBlockOriginal) return false;

    void* player = playerFromGameMode(gameMode);
    void* region = regionFromPlayer(player);

    // Capture the block name BEFORE vanilla replaces it with air.
    std::string originalName;
    if (region) {
        const auto name = blockName(region, pos);
        if (!name.empty()) originalName.assign(name.data(), name.size());
    }

    const bool destroyed = g_destroyBlockOriginal(gameMode, pos, face);
    if (!destroyed || !enabled || !region || originalName.empty() || !acceptsBlock(originalName)) {
        return destroyed;
    }

    // A manual break starts a new vein. Queued blocks are executed through the
    // original trampoline, so they do not recursively create another vein.
    clearQueue();
    m_activeGameMode = gameMode;
    m_activePlayer = player;
    m_targetBlockName = originalName;
    buildVein(region, pos, originalName, face);
    return destroyed;
}

void VeinMinerModule::buildVein(void* region, const BlockPos& origin, std::string_view targetName, std::uint8_t face) {
    if (!region || targetName.empty()) return;

    const int maxBlocks = std::clamp(m_maxBlocks, 1, 128);
    std::vector<BlockPos> frontier;
    frontier.reserve(static_cast<std::size_t>(maxBlocks) + 1);
    frontier.push_back(origin);

    std::unordered_set<BlockPos, PosHash, PosEqual> visited;
    visited.reserve(static_cast<std::size_t>(maxBlocks) * 3 + 8);
    visited.insert(origin);

    std::array<BlockPos, 26> neighbors{};
    int neighborCount = 0;
    for (int dx = -1; dx <= 1; ++dx) {
        for (int dy = -1; dy <= 1; ++dy) {
            for (int dz = -1; dz <= 1; ++dz) {
                if (dx == 0 && dy == 0 && dz == 0) continue;
                if (!m_diagonalConnections && (std::abs(dx) + std::abs(dy) + std::abs(dz) != 1)) continue;
                neighbors[neighborCount++] = {dx, dy, dz};
            }
        }
    }

    std::size_t cursor = 0;
    while (cursor < frontier.size() && static_cast<int>(m_queue.size()) < maxBlocks - 1) {
        const BlockPos current = frontier[cursor++];
        for (int i = 0; i < neighborCount && static_cast<int>(m_queue.size()) < maxBlocks - 1; ++i) {
            const BlockPos next{
                current.x + neighbors[i].x,
                current.y + neighbors[i].y,
                current.z + neighbors[i].z,
            };

            if (!visited.insert(next).second) continue;
            if (blockName(region, next) != targetName) continue;

            frontier.push_back(next);
            m_queue.push_back({next, face});
        }
    }
}

void VeinMinerModule::onLocalPlayerTick(void* player) {
    if (!enabled || m_queue.empty() || !g_destroyBlockOriginal || !m_activeGameMode) return;
    if (!player || player != m_activePlayer) {
        clearQueue();
        return;
    }

    void* region = regionFromPlayer(player);
    if (!region) {
        clearQueue();
        return;
    }

    const int perTick = std::clamp(m_blocksPerTick, 1, 8);
    int processed = 0;
    while (processed < perTick && !m_queue.empty()) {
        const QueuedBlock next = m_queue.front();
        m_queue.pop_front();

        // The world may have changed since the BFS was built. Only destroy the
        // exact block type that originated this vein.
        if (blockName(region, next.pos) == m_targetBlockName) {
            g_destroyBlockOriginal(m_activeGameMode, next.pos, next.face);
        }
        ++processed;
    }

    if (m_queue.empty()) clearQueue();
}

void VeinMinerModule::loadConfig(const nlohmann::json& j) {
    Module::loadConfig(j);

    if (j.contains("mode")) {
        const auto& value = j["mode"];
        try {
            int mode = 0;
            if (value.is_string()) {
                const std::string text = value.get<std::string>();
                mode = std::stoi(text.substr(0, text.find(',')));
            } else if (value.is_number_integer()) {
                mode = value.get<int>();
            }
            if (mode >= static_cast<int>(Mode::Ores) && mode <= static_cast<int>(Mode::SameBlock)) {
                m_mode = static_cast<Mode>(mode);
            }
        } catch (...) {}
    }

    if (j.contains("maxBlocks")) m_maxBlocks = std::clamp(j["maxBlocks"].get<int>(), 1, 128);
    if (j.contains("blocksPerTick")) m_blocksPerTick = std::clamp(j["blocksPerTick"].get<int>(), 1, 8);
    if (j.contains("diagonalConnections")) m_diagonalConnections = j["diagonalConnections"].get<bool>();
}

void VeinMinerModule::saveConfig(nlohmann::json& j) {
    Module::saveConfig(j);
    j["mode"] = std::to_string(static_cast<int>(m_mode)) + ",Ores,Logs,Same Block";
    j["maxBlocks"] = m_maxBlocks;
    j["blocksPerTick"] = m_blocksPerTick;
    j["diagonalConnections"] = m_diagonalConnections;
}
