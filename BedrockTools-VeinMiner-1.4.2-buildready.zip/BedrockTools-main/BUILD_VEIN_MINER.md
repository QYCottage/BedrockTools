# Vein Miner build / installation

This source tree contains the Vein Miner module registered in `src/modules/ModuleRegistry.cpp`.
The source ZIP itself is NOT installable in LeviLauncher. You must build `BedrockTools.levipack`.

## Easiest method: GitHub Actions

1. Create a GitHub repository and upload the CONTENTS of this folder to it.
2. Keep `.github/workflows/build.yml` in the repository.
3. Push/commit to `main` or `master`, or open the **Actions** tab and run the **Build** workflow manually.
4. Open the finished **Build** workflow run.
5. Download the artifact named `BedrockTools-levipack`.
6. Extract the artifact ZIP. It contains `BedrockTools.levipack`.
7. In LeviLauncher, disable/remove the old BedrockTools 1.4.1 installation.
8. Import the newly built BedrockTools 1.4.2 `.levipack` and enable it.
9. Fully close Minecraft/LeviLauncher and launch Minecraft again through LeviLauncher.
10. Open the BedrockTools mod menu. `Vein Miner` should be listed with the other modules.

## Local build

Requirements: Android NDK r28c, xmake, Python 3.

```sh
xmake f -y -p android -a arm64-v8a -m release --ndk=/path/to/android-ndk-r28c
xmake -y
```

Output:

`build/android/arm64-v8a/release/BedrockTools.levipack`

## Verification in the source

The module must appear in all three places:

- `src/modules/player/veinminer.hpp`
- `src/modules/player/veinminer.cpp`
- `src/modules/ModuleRegistry.cpp` -> `registry.emplace<VeinMinerModule>();`

`xmake.lua` already compiles `src/modules/**.cpp`, so no extra source-list entry is required.
